package main

type Settings struct {
	Admin        string `json:"admin"`
}

type Asset struct {
	History    	[]string `json:"history"`
	Value   	uint64 `json:"value"`
}

type User struct {
	Role    	string `json:"role"`
	Name        string `json:"name"`
	Balance   	uint64 `json:"userBalance"`
}

type Gift struct {
	Receiver    string `json:"receiver"`
	Value uint64 `json:"value"`
}

type Transfer struct {
	From  string `json:"from"`
	To    string `json:"to"`
	Value uint64 `json:"value"`
}

type Approve struct {
	Spender string `json:"spender"`
	Value   uint64 `json:"value"`
}