package main

import (
	"encoding/binary"
	"errors"
	"encoding/json"
	"github.com/hyperledger/fabric/core/chaincode/shim"
	pb "github.com/hyperledger/fabric/protos/peer"
	"strconv"
)

func (t *LoyaltyChaincode) userBalanceAsJson(stub shim.ChaincodeStubInterface, args []string) pb.Response {
	if len(args) != 1 {
		return shim.Error("Expected user to query")
	}
	balanceRq := User{}
	if err := json.Unmarshal([]byte(args[0]), &balanceRq); err != nil {
		return shim.Error(err.Error())
	}

	balance, err := t.userBalance(stub, balanceRq.Name)
	if err != nil {
		return shim.Error("Error getting userBalance: " + err.Error())
	}

	balanceJson := User{
		Name:  balanceRq.Name,
		Balance: balance,
	}

	result, _ := json.Marshal(balanceJson)
	return shim.Success(result)
}

func (t *LoyaltyChaincode) setInitUserBalance(stub shim.ChaincodeStubInterface, prefix string, cn string, balance uint64) error {

	if balance < 0 {
		return errors.New("balance can't be negative")
	}

	key, _ := stub.CreateCompositeKey(prefix, []string{cn})
	data := make([]byte, 8)
	binary.LittleEndian.PutUint64(data, balance)
	return stub.PutState(key, data)
}

func (t *LoyaltyChaincode) setUserBalance(stub shim.ChaincodeStubInterface, prefix string, cn string, balance uint64) error {

	if balance < 0 {
		return errors.New("balance can't be negative")
	}

	key, _ := stub.CreateCompositeKey(prefix, []string{cn})
	data, err := stub.GetState(key)
	if err != nil {
		return err
	} else if data == nil {
		return errors.New("User '" + cn + "' doesn't exist")
	}

	newBalance := binary.LittleEndian.Uint64(data)
	newBalance += balance

	data = make([]byte, 8)
	binary.LittleEndian.PutUint64(data, newBalance)
	return stub.PutState(key, data)
}

func (t *LoyaltyChaincode) userBalance(stub shim.ChaincodeStubInterface, cn string) (uint64, error) {
	key, _ := stub.CreateCompositeKey(IndexCustomer, []string{cn})
	data, err := stub.GetState(key)
	if err != nil {
		return 0, err
	}

	// if the user cn is not in the state, then the userBalance is 0
	if data == nil {
		return 0, nil
	}

	return binary.LittleEndian.Uint64(data), nil
}


func (t *LoyaltyChaincode) countExistingGiftsFromBankToUser(stub shim.ChaincodeStubInterface, bankCn string, userCn string) (int, error)  {


	iterator, err := stub.GetStateByPartialCompositeKey(IndexCustomer, []string{userCn, bankCn})
	if err != nil {
		return 0, err
	}
	defer iterator.Close()
	var num = 0

	for i := 0; iterator.HasNext(); i++ {
		_ , err = iterator.Next()
		num++
	}

	if err != nil {
		return 0, err
	}

	return num, nil
}

func (t *LoyaltyChaincode) makeGiftToTheUser(stub shim.ChaincodeStubInterface, bankCn string, userCn string, balance uint64) error {

	if balance < 0 {
		return errors.New("gift to the user can't be negative")
	}

	num, err := t.countExistingGiftsFromBankToUser(stub, bankCn, userCn)
	if err != nil {
		return err
	}

	key, _ := stub.CreateCompositeKey(IndexCustomerAsset, []string{userCn, bankCn, strconv.Itoa(num)})
	newAssetStr := `{"history": ["` + bankCn + `"], "value": ` + uintToString(balance) + `}`
	err = stub.PutState(key, []byte(newAssetStr))
	if err != nil {
		return err
	}

	key, _ = stub.CreateCompositeKey(IndexBanksCustomers, []string{bankCn, userCn})
	newBallance := balance
	data, err := stub.GetState(key)
	if err != nil {
		return err
	}

	if data != nil {
		newBallance += binary.LittleEndian.Uint64(data)
	}

	data = make([]byte, 8)
	binary.LittleEndian.PutUint64(data, newBallance)

	err = stub.PutState(key, data)
	if err != nil {
		return err
	}


	return t.setUserBalance(stub, IndexCustomer, userCn, balance)
}


func (t *LoyaltyChaincode) getBanksCustomers(stub shim.ChaincodeStubInterface, bankCn string) ([]*User, error) {

	iterator, err := stub.GetStateByPartialCompositeKey(IndexBanksCustomers, []string{bankCn})
	if err != nil {
		return nil, err
	}
	defer iterator.Close()

	var result []*User = []*User{}
	for i := 0; iterator.HasNext(); i++ {
		kv, err := iterator.Next()

		if err != nil {
			return nil, err
		}

		_, parts, err := stub.SplitCompositeKey(kv.Key)
		cName := parts[1]
		cBalance := kv.Value

		customer := User{
			Name: cName,
			Balance:  binary.LittleEndian.Uint64(cBalance),
		}

		result = append(result, &customer)
	}

	return result, nil
}